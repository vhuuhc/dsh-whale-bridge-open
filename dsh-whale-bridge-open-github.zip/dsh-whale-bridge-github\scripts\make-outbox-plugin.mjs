#!/usr/bin/env node
/**
 * Install / refresh the Whale-side OUTBOUND plugin (`whale-dsh-outbox`).
 *
 * It polls the DSH bridge's `/outbox` endpoint on a timer and sends whatever it
 * finds to WeChat: text with `whale.sendText`, images with `whale.sendImage`.
 * That is the only way a message DSH produced on its own initiative can reach
 * WeChat: the chat hook only runs as a reply to an inbound message.
 *
 * Why images are special (verified against Whale 4.1.7 / bridge sources):
 *  - `sendText` goes into Whale's reminder queue and is delivered by the
 *    background channel (window messages), so it works while WeChat is
 *    minimised or hidden.
 *  - `sendImage` does not. `pluginHost.send()` turns it into a sticker job and
 *    `bridge/sticker_mixin.py` refuses to touch it unless WeChat already owns
 *    the foreground; it tries exactly one plain `SetForegroundWindow`, which
 *    Windows' foreground lock rejects whenever another app has focus. That is
 *    the entire "sometimes it sends, sometimes it silently doesn't" behaviour.
 *    We therefore hold the WeChat window in front ourselves (AttachThreadInput
 *    + BringWindowToTop, the trick the bridge deliberately avoids) for the few
 *    seconds a send takes, then put the previous window back.
 *  - `sendImage` only *queues*; the real outcome arrives later. Acking right
 *    after the call drops failures on the floor, so we poll
 *    `whale.delivery(id)` until the job reaches a terminal state.
 *  - A leftover draft in the target chat blocks every later image send until a
 *    human clears it. That is reported as `draft_blocked` and retried slowly
 *    instead of every tick.
 *
 * The runtime scans `<Whale>/data/plugins` for `<id>.flow.json` paired with
 * `<id>.flow-grant.json`; the grant hash is sha256 over the JSON.stringify(flow)
 * bytes. Changing the JS means a new hash and therefore a fresh consent prompt
 * in the launcher — that is intended.
 *
 *   node scripts/make-outbox-plugin.mjs            # dry run: print target + hash
 *   node scripts/make-outbox-plugin.mjs --apply    # write the three files
 */
import { writeFile, mkdir } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { join } from 'node:path';
import { existsSync } from 'node:fs';

export const ID = 'whale-dsh-outbox';

const SOURCE = String.raw`'use strict';
/**
 * 鲸鲸 ← DSH 出站队列。
 *
 * DSH 那边把"不是用户问出来的"助手消息放进 /outbox；这个插件每 10 秒拉一次：
 *   文字 → whale.sendText（走后台通道，微信最小化也能发）
 *   图片 → whale.sendImage（走表情包/附件通道，必须微信在前台，见 holdFront）
 * 确认发出去才回执，没发成留着下一轮，并写 last-error.json 说明原因。
 */
const whale = require('whale');
const fs = require('node:fs');
const path = require('node:path');
const { execFile } = require('node:child_process');

const TERMINAL = new Set(['confirmed', 'unconfirmed', 'failed', 'cancelled']);
const IMAGE_POLL_MS = 9000;      // 等桥接领走并回执的上限
const HOLD_MS = 20000;           // 窗口最多被占用多久（脚本自己会还原）
const IMAGE_STUCK_MS = 60000;    // 一直卡在 queued/sending 多久算失败
const BACKOFF_MS = [15000, 45000, 120000, 300000];
const DRAFT_BACKOFF_MS = 180000; // 输入框有草稿时只有人手能救，别一直抢前台
const MAX_IMAGES_PER_TICK = 2;

// 窗口脚本。Whale 自己的 activate() 只调一次 SetForegroundWindow，被前台锁拒绝
// 就放弃；这里用 AttachThreadInput + BringWindowToTop，实测能把最小化的微信拉到
// 前台。hold 模式在发送期间一直压着，收到 flag 文件或到时后把原窗口还原。
const PS1 = [
  "param([string]$Action='activate',[Int64]$Original=0,[Int64]$Target=0,[int]$Iconic=0,[string]$Flag='',[int]$MaxMs=15000)",
  "$ErrorActionPreference='Stop'",
  "$cs = @'",
  'using System;',
  'using System.Runtime.InteropServices;',
  'public class WhaleFg {',
  '  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();',
  '  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);',
  '  [DllImport("user32.dll")] public static extern bool ShowWindowAsync(IntPtr h, int n);',
  '  [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr h);',
  '  [DllImport("user32.dll")] public static extern bool IsWindow(IntPtr h);',
  '  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);',
  '  [DllImport("user32.dll")] public static extern bool AttachThreadInput(uint a, uint b, bool f);',
  '  [DllImport("kernel32.dll")] public static extern uint GetCurrentThreadId();',
  '  [DllImport("user32.dll")] public static extern bool BringWindowToTop(IntPtr h);',
  '}',
  "'@",
  'Add-Type -TypeDefinition $cs',
  'function Focus([Int64]$h) {',
  '  if ($h -eq 0) { return $false }',
  '  if (-not [WhaleFg]::IsWindow([IntPtr]$h)) { return $false }',
  '  $p = [Int64][WhaleFg]::GetForegroundWindow()',
  '  if ($p -eq $h) { return $true }',
  '  if ([WhaleFg]::IsIconic([IntPtr]$h)) { [void][WhaleFg]::ShowWindowAsync([IntPtr]$h, 9); Start-Sleep -Milliseconds 250 }',
  '  [uint32]$fgPid = 0',
  '  $tid = [WhaleFg]::GetWindowThreadProcessId([IntPtr]$p, [ref]$fgPid)',
  '  $cur = [WhaleFg]::GetCurrentThreadId()',
  '  $attached = $false',
  '  if (($tid -ne 0) -and ($tid -ne $cur)) { $attached = [WhaleFg]::AttachThreadInput($cur, $tid, $true) }',
  '  [void][WhaleFg]::BringWindowToTop([IntPtr]$h)',
  '  [void][WhaleFg]::SetForegroundWindow([IntPtr]$h)',
  '  if ($attached) { [void][WhaleFg]::AttachThreadInput($cur, $tid, $false) }',
  '  Start-Sleep -Milliseconds 180',
  '  return ([Int64][WhaleFg]::GetForegroundWindow() -eq $h)',
  '}',
  'function FindWeChat() {',
  '  foreach ($proc in @(Get-Process -Name Weixin,WeChat -ErrorAction SilentlyContinue)) {',
  '    $m = [Int64]$proc.MainWindowHandle',
  '    if ($m -ne 0) { return $m }',
  '  }',
  '  return [Int64]0',
  '}',
  "if ($Action -eq 'activate') {",
  '  $target = FindWeChat',
  '  if ($target -eq 0) { \'{"ok":false,"reason":"no_window"}\'; exit 0 }',
  '  $orig = [Int64][WhaleFg]::GetForegroundWindow()',
  '  $wasIconic = [WhaleFg]::IsIconic([IntPtr]$target)',
  '  $ok = Focus $target',
  '  \'{"ok":\' + $ok.ToString().ToLower() + \',"fg":\' + $orig + \',"hwnd":\' + $target + \',"iconic":\' + $wasIconic.ToString().ToLower() + \'}\'',
  '  exit 0',
  '}',
  "if ($Action -eq 'hold') {",
  '  $log = $Flag + \'.log\'',
  '  try {',
  "  ('start ' + (Get-Date).ToString('HH:mm:ss') + ' maxMs=' + $MaxMs) | Out-File -LiteralPath $log -Append -Encoding utf8",
  '  $target = FindWeChat',
  '  if ($target -eq 0) { \'{"ok":false,"reason":"no_window"}\'; exit 0 }',
  '  $orig = [Int64][WhaleFg]::GetForegroundWindow()',
  '  $wasIconic = [WhaleFg]::IsIconic([IntPtr]$target)',
  '  $ok = Focus $target',
  "  ('focus=' + $ok + ' orig=' + $orig + ' target=' + $target + ' now=' + [WhaleFg]::GetForegroundWindow()) | Out-File -LiteralPath $log -Append -Encoding utf8",
  '  Set-Content -LiteralPath ($Flag + \'.ready\') -Value \'1\' -Encoding ascii',
  '  $start = Get-Date',
  '  $deadline = $start.AddMilliseconds($MaxMs)',
  '  $reassertUntil = $start.AddMilliseconds(6000)',
  '  while ((Get-Date) -lt $deadline) {',
  '    if (($Flag -ne \'\') -and (Test-Path -LiteralPath $Flag)) { break }',
  '    if ((Get-Date) -lt $reassertUntil) {',
  '      if ([Int64][WhaleFg]::GetForegroundWindow() -ne $target) { [void](Focus $target) }',
  '    }',
  '    Start-Sleep -Milliseconds 400',
  '  }',
  '  if ($wasIconic) { [void][WhaleFg]::ShowWindowAsync([IntPtr]$target, 6); Start-Sleep -Milliseconds 150 }',
  '  $back = Focus $orig',
  "  ('end restored=' + $back + ' after=' + [int]((Get-Date) - $start).TotalSeconds + 's') | Out-File -LiteralPath $log -Append -Encoding utf8",
  '  \'{"ok":\' + $ok.ToString().ToLower() + \',"restored":\' + $back.ToString().ToLower() + \',"fg":\' + $orig + \',"hwnd":\' + $target + \'}\'',
  '  } catch {',
  "  ('error ' + $_.Exception.Message) | Out-File -LiteralPath $log -Append -Encoding utf8",
  '  \'{"ok":false,"reason":"exception"}\'',
  '  }',
  '  exit 0',
  '}',
  "if ($Action -eq 'restore') {",
  '  if (($Iconic -eq 1) -and ($Target -ne 0)) { [void][WhaleFg]::ShowWindowAsync([IntPtr]$Target, 6); Start-Sleep -Milliseconds 150 }',
  '  $ok = Focus $Original',
  '  \'{"ok":\' + $ok.ToString().ToLower() + \'}\'',
  '  exit 0',
  '}',
].join('\n');

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function bridgeConfig() {
  const candidates = [
    path.join(process.cwd(), '..', 'whale-dsh-bridge.data', 'config.json'),
    path.join(process.cwd(), 'config.json'),
  ];
  for (const file of candidates) {
    try {
      const raw = JSON.parse(fs.readFileSync(file, 'utf8'));
      if (raw && typeof raw.url === 'string' && raw.url && typeof raw.token === 'string' && raw.token) {
        return { url: raw.url.replace(/\/+$/, ''), token: raw.token };
      }
    } catch (error) { /* try next candidate */ }
  }
  return null;
}

async function request(cfg, method, suffix, body) {
  const init = { method, headers: { authorization: 'Bearer ' + cfg.token } };
  if (body !== undefined) {
    init.headers['content-type'] = 'application/json';
    init.body = JSON.stringify(body);
  }
  const response = await fetch(cfg.url + suffix, init);
  if (!response.ok) throw new Error('http_' + response.status);
  return await response.json();
}

function dataDir() {
  try {
    if (whale.paths && whale.paths.pluginData) return whale.paths.pluginData;
  } catch (error) { /* fall through */ }
  return process.cwd();
}

function noteError(payload) {
  try {
    fs.writeFileSync(path.join(dataDir(), 'last-error.json'), JSON.stringify(payload, null, 2));
  } catch (error) { /* diagnostics must never break the tick */ }
}

function scriptPath() {
  const file = path.join(dataDir(), 'window.ps1');
  try {
    if (fs.readFileSync(file, 'utf8') === PS1) return file;
  } catch (error) { /* not written yet */ }
  fs.writeFileSync(file, PS1, 'utf8');
  return file;
}

function powerShellPath() {
  const root = process.env.SystemRoot || process.env.windir || 'C:\\Windows';
  const full = path.join(root, 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe');
  try { if (fs.existsSync(full)) return full; } catch (error) { /* fall through */ }
  return 'powershell.exe';
}

function runPs1(args) {
  return new Promise((resolve) => {
    let file;
    try { file = scriptPath(); } catch (error) { return resolve(null); }
    execFile(powerShellPath(),
      ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', file].concat(args),
      { timeout: 12000, windowsHide: true },
      (error, stdout) => {
        if (error) return resolve(null);
        const lines = String(stdout || '').trim().split(/\r?\n/);
        const text = lines[lines.length - 1] || '';
        try { resolve(JSON.parse(text)); } catch (e) { resolve(null); }
      });
  });
}

/** End the foreground hold early; the script restores the previous window. */
function stopHold(state) {
  if (state.flag) {
    try { fs.writeFileSync(state.flag, '1'); } catch (error) { /* the script times out on its own */ }
  }
  if (state.ready) {
    try { fs.rmSync(state.ready, { force: true }); } catch (error) { /* already gone */ }
  }
  state.flag = null;
  state.ready = null;
}

/** Wait until the helper reports that WeChat really is in front. */
async function waitReady(state, ms) {
  const deadline = Date.now() + ms;
  while (Date.now() < deadline) {
    try { if (fs.existsSync(state.ready)) return true; } catch (error) { /* keep waiting */ }
    await sleep(150);
  }
  return false;
}

/** Keep WeChat in front for the duration of one send (detached, bounded by HOLD_MS). */
function startHold(state) {
  stopHold(state);
  const dir = dataDir();
  const flag = path.join(dir, 'hold-' + state.key + '.flag');
  const ready = flag + '.ready';
  try {
    for (const name of fs.readdirSync(dir)) {
      if (name.startsWith('hold-') && path.join(dir, name) !== flag) {
        fs.rmSync(path.join(dir, name), { force: true });
      }
    }
  } catch (error) { /* best effort */ }
  try { fs.rmSync(flag, { force: true }); } catch (error) { /* fresh file */ }
  try { fs.rmSync(ready, { force: true }); } catch (error) { /* fresh file */ }
  let file;
  try { file = scriptPath(); } catch (error) { return false; }
  // Fire and forget: the helper keeps WeChat in front until the flag file appears
  // or HOLD_MS elapses, then restores the previous window by itself.
  try {
    execFile(powerShellPath(),
      ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', file,
        '-Action', 'hold', '-Flag', flag, '-MaxMs', String(HOLD_MS)],
      { timeout: HOLD_MS + 10000, windowsHide: true },
      (error) => {
        if (error && error.killed !== true) {
          noteError({ at: new Date().toISOString(), error: 'hold_failed', detail: String(error.message || error) });
        }
      });
  } catch (error) {
    noteError({ at: new Date().toISOString(), error: 'hold_spawn_failed', detail: String((error && error.message) || error) });
    return false;
  }
  state.flag = flag;
  state.ready = ready;
  return true;
}

async function deliveryOf(id) {
  try {
    const out = await whale.delivery(id);
    return out && typeof out === 'object' ? out : null;
  } catch (error) {
    return null;
  }
}

/** Retry bookkeeping: back off instead of hammering a broken window. */
function scheduleRetry(state, wait) {
  const ms = typeof wait === 'number' && wait > 0
    ? wait
    : BACKOFF_MS[Math.min(state.tries, BACKOFF_MS.length - 1)];
  state.tries += 1;
  state.nextAt = Date.now() + ms;
  state.jobId = null;
  state.actAt = 0;
}

async function sendImageItem(item, state) {
  if (Date.now() < state.nextAt) return 'quiet';
  if (!item.file || !fs.existsSync(item.file)) {
    noteError({ at: new Date().toISOString(), error: 'image_missing', file: item.file || null });
    scheduleRetry(state);
    return 'quiet';
  }
  // Resume an attempt whose result had not arrived yet.
  if (state.jobId) {
    const done = await deliveryOf(state.jobId);
    if (done && TERMINAL.has(done.status)) { stopHold(state); return finishImage(item, state, done); }
    if (!state.actAt || Date.now() - state.actAt < IMAGE_STUCK_MS) return 'quiet';
    noteError({ at: new Date().toISOString(), error: 'image_stuck', status: done ? done.status : 'unknown' });
    stopHold(state);
    scheduleRetry(state);
    return 'quiet';
  }
  if (!startHold(state)) {
    noteError({ at: new Date().toISOString(), error: 'window_helper_failed' });
    scheduleRetry(state);
    return 'quiet';
  }
  if (!(await waitReady(state, 6000))) {
    noteError({
      at: new Date().toISOString(), error: 'window_hold_timeout',
      hint: '拉不起微信窗口（锁屏 / 全屏独占 / 找不到微信进程），解锁后会自动重试',
    });
    stopHold(state);
    scheduleRetry(state);
    return 'quiet';
  }
  state.actAt = Date.now();
  let queued = null;
  try {
    queued = await whale.sendImage(item.chatId, item.file);
  } catch (error) {
    noteError({ at: new Date().toISOString(), error: 'send_rejected', detail: String((error && (error.message || error)) || error) });
    stopHold(state);
    scheduleRetry(state);
    return 'quiet';
  }
  state.jobId = queued && queued.id ? String(queued.id) : null;
  if (!state.jobId) {
    noteError({ at: new Date().toISOString(), error: 'no_delivery_id' });
    stopHold(state);
    scheduleRetry(state);
    return 'quiet';
  }
  const deadline = Date.now() + IMAGE_POLL_MS;
  let last = null;
  while (Date.now() < deadline) {
    last = await deliveryOf(state.jobId);
    if (last && TERMINAL.has(last.status)) { stopHold(state); return finishImage(item, state, last); }
    await sleep(500);
  }
  return 'quiet';
}

async function finishImage(item, state, done) {
  if (done.status === 'confirmed' || done.status === 'unconfirmed') {
    // unconfirmed 表示可能已经贴进输入框但没读到达送证据；再发一次会重复，所以算发过。
    if (done.status === 'unconfirmed') {
      noteError({ at: new Date().toISOString(), error: 'image_unconfirmed', detail: String(done.error || '') });
    }
    return 'sent';
  }
  const detail = String(done.error || '');
  // 输入框里有没发出去的草稿时，桥接会一直拒绝发送，只有人手能清空。
  if (/draft|草稿/i.test(detail)) {
    noteError({
      at: new Date().toISOString(), error: 'draft_blocked', status: done.status, detail,
      hint: '微信那个会话的输入框里有没发出去的草稿；点进该会话清空输入框后 3 分钟内会自动补发',
      file: item.file || null,
    });
    scheduleRetry(state, DRAFT_BACKOFF_MS);
    return 'quiet';
  }
  noteError({
    at: new Date().toISOString(), error: 'image_failed', status: done.status,
    detail, file: item.file || null,
  });
  scheduleRetry(state);
  return 'quiet';
}

async function tick() {
  const cfg = bridgeConfig();
  if (!cfg) return { ok: false, reason: 'no_bridge_config' };
  let items = [];
  try {
    const body = await request(cfg, 'GET', '/outbox?limit=10');
    items = Array.isArray(body.items) ? body.items : [];
  } catch (error) {
    return { ok: false, reason: String((error && error.message) || error) };
  }
  // 图片走表情包通道；总闸关着时一切都是空转，直接留队列并说明原因。
  if (items.some((item) => item && item.kind === 'image')) {
    let stickersOn = true;
    try {
      const state = await whale.api('/api/features');
      const row = ((state && state.features) || []).find((f) => f.key === 'stickers');
      stickersOn = !row || row.value !== false;
    } catch (error) { stickersOn = true; }
    if (!stickersOn) {
      noteError({
        at: new Date().toISOString(), error: 'stickers_disabled',
        hint: '鲸鲸设置 → 功能开关 → 表情包（实验性）需要打开，否则发不了图片',
      });
      return { ok: false, reason: 'stickers_disabled', pending: items.length };
    }
  }
  const sent = [];
  let images = 0;
  for (const item of items) {
    if (!item || typeof item.id !== 'string' || typeof item.chatId !== 'string') continue;
    const isImage = item.kind === 'image';
    if (isImage && typeof item.file !== 'string') continue;
    if (!isImage && typeof item.text !== 'string') continue;
    if (isImage) {
      if (images >= MAX_IMAGES_PER_TICK) continue;
      images += 1;
      const state = imageState.get(item.id)
        || { key: item.id, tries: 0, nextAt: 0, jobId: null, flag: null, actAt: 0 };
      imageState.set(item.id, state);
      const outcome = await sendImageItem(item, state);
      if (outcome === 'sent') { sent.push(item.id); imageState.delete(item.id); }
      continue;
    }
    try {
      await whale.sendText(item.chatId, item.text);
      sent.push(item.id);
    } catch (error) {
      /* keep it queued for the next tick, but leave a trail for diagnosis */
      noteError({
        at: new Date().toISOString(), id: item.id, kind: item.kind,
        error: String((error && (error.message || error)) || error),
      });
    }
  }
  if (sent.length) {
    try { await request(cfg, 'POST', '/outbox/ack', { ids: sent }); } catch (error) { /* retry next tick */ }
    for (const id of sent) imageState.delete(id);
  }
  return { ok: true, sent: sent.length, pending: items.length - sent.length };
}

const imageState = new Map();

exports.hooks = { 'timer.tick': tick };
exports.run = async () => ({ ok: true, detail: '把 DSH 主动说的话和图片发到微信（出站队列）' });
`;

export function buildFlow() {
  return {
    id: ID,
    api: 4,
    kind: 'message',
    hooks: ['timer.tick'],
    permissions: ['system.full'],
    // 一张图要等桥接领走 + 回执，最长约 9 秒；超时必须够宽，否则半截被打断。
    executionTimeoutMs: 30000,
    intervalSeconds: 10,
    javascript: SOURCE,
  };
}

/**
 * Grant hash is sha256 over the FLOW FILE BYTES, and the loader compares it to
 * that of the file it actually read. The file therefore has to be written as
 * compact JSON (`JSON.stringify(flow)`), exactly the bytes we hash: pretty
 * printing produced a hash mismatch and the plugin was silently skipped.
 */
export function flowBytes(flow = buildFlow()) {
  return Buffer.from(JSON.stringify(flow), 'utf8');
}

export function grantHash(flow = buildFlow()) {
  return createHash('sha256').update(flowBytes(flow)).digest('hex');
}

export function packageManifest() {
  return {
    Id: ID,
    Name: 'DSH 出站队列',
    Author: 'vhuuhc',
    Version: '1.2.0',
    MinAppVersion: '4.1.2',
    Description: '把 DSH 主动说的话和图片发到对应的微信会话。每 10 秒拉一次 DSH 的出站队列：文字用 sendText，图片用 sendImage（发送期间把微信窗口临时保持在前台，完成或 15 秒后自动还原），确认送达才回执，失败留到下一轮并写 last-error.json。需要先装「DSH 桥接」。',
    ResultLabel: '发送',
    Api: 4,
    Kind: 'message',
    Hooks: ['timer.tick'],
    Permissions: ['system.full'],
    ExecutionTimeoutMs: 30000,
  };
}

export function whalePluginsDir() {
  const explicit = String(process.env.WHALE_ROOT || '').trim();
  const candidates = [
    explicit ? join(explicit, 'data', 'plugins') : null,
    process.env.LOCALAPPDATA ? join(process.env.LOCALAPPDATA, 'Programs', 'WhaleGirl', 'data', 'plugins') : null,
    process.env.LOCALAPPDATA ? join(process.env.LOCALAPPDATA, 'WhaleGirl', 'data', 'plugins') : null,
  ].filter(Boolean);
  for (const dir of candidates) if (existsSync(dir)) return dir;
  return null;
}

async function main() {
  const apply = process.argv.includes('--apply');
  const emitIndex = process.argv.indexOf('--emit');
  const emitDir = emitIndex > -1 ? process.argv[emitIndex + 1] : null;
  const flow = buildFlow();
  const bytes = flowBytes(flow);
  const hash = grantHash(flow);

  // Market package: a ZIP whose root holds exactly plugin.json + plugin.js.
  if (emitDir) {
    await mkdir(emitDir, { recursive: true });
    await writeFile(join(emitDir, 'plugin.json'), JSON.stringify(packageManifest(), null, 2) + '\n', 'utf8');
    await writeFile(join(emitDir, 'plugin.js'), flow.javascript, 'utf8');
    console.log('emitted package sources to ' + emitDir);
    return;
  }

  const dir = whalePluginsDir();
  if (!dir) {
    console.error('找不到鲸鲸插件目录：设置 WHALE_ROOT 指向 WhaleGirl 安装目录后重试');
    process.exit(2);
  }
  console.log('dir   = ' + dir);
  console.log('id    = ' + flow.id + '  api=' + flow.api + '  hooks=' + flow.hooks.join(',') + '  interval=' + flow.intervalSeconds + 's');
  console.log('hash  = ' + hash + '   (sha256 of the flow file bytes)');
  if (!apply) { console.log('\n这是预演。加 --apply 才会写文件。'); return; }
  await mkdir(join(dir, ID + '.data'), { recursive: true });
  // Compact JSON on purpose: the grant hash covers these exact bytes.
  await writeFile(join(dir, ID + '.flow.json'), bytes);
  await writeFile(join(dir, ID + '.flow-grant.json'), JSON.stringify({ enabled: true, fullAccess: true, hash, settings: {} }, null, 2) + '\n', 'utf8');
  await writeFile(join(dir, ID + '.enabled'), '', 'utf8');
  console.log('written: ' + [ID + '.flow.json', ID + '.flow-grant.json', ID + '.enabled'].join(', '));
  console.log('若鲸鲸没热加载，重启一次；启动器要求授权时确认 full-access。');
}

if (process.argv[1] && process.argv[1].endsWith('make-outbox-plugin.mjs')) {
  main().catch((error) => { console.error(error); process.exit(1); });
}
