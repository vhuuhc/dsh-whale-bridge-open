import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, readFile } from 'node:fs/promises';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { createRelay, lastAssistantText, assistantTextFromEvent, RelayError } from '../relay.mjs';

const assistant = (text, extra = {}) => ({
  event: { type: 'assistant/message', seq: 2, data: { turn: 1, step: 1, message: { content: [{ type: 'text', text }] }, ...extra } },
});

const needsSignal = (name) => (signal) => {
  assert.ok(signal && typeof signal.throwIfAborted === 'function', name + ' needs an AbortSignal');
};

async function stateFile() {
  const dir = await mkdtemp(join(tmpdir(), 'relay-'));
  return join(dir, 'relay-sessions.json');
}

function fakePermission(applied = []) {
  return {
    value: undefined,
    set(session, name) { this.value = name; applied.push({ session, name }); },
    current() { return this.value; },
  };
}

function fakeController({ reply = '你好呀', createCalls = [], onPrompt = null } = {}) {
  let cursor = 0;
  const prompts = [];
  return {
    prompts,
    async create(req) { createCalls.push(req); return { sessionId: req.sessionId, agentPreset: req.agentPreset }; },
    async state(_req, signal) { needsSignal('state')(signal); return { cursor, active: true, running: true, queue: null, pendingInput: [] }; },
    async prompt(req, signal) { needsSignal('prompt')(signal); prompts.push(req); if (onPrompt) onPrompt(req); cursor += 2; return { accepted: true }; },
    async wait(_req, signal) {
      needsSignal('wait')(signal);
      return { reason: 'idle', state: { cursor, running: false }, output: { records: [assistant(reply)], truncated: false } };
    },
    async cancel() {},
  };
}

const wiring = (api, extra = {}) => ({
  getController: () => api,
  getPermission: () => ('permission' in extra ? extra.permission : fakePermission()),
  getSession: () => ('session' in extra ? extra.session : { id: 'live-session' }),
  ...extra.overrides,
});

test('extracts only visible text parts', () => {
  assert.equal(assistantTextFromEvent({ data: { message: { content: [{ type: 'reasoning', text: '想' }, { type: 'text', text: '答' }] } } }), '答');
  assert.equal(assistantTextFromEvent({ data: { message: { content: [{ type: 'text', text: 'x' }] }, interrupted: true } }), '');
  assert.equal(lastAssistantText([assistant('a'), { event: { type: 'tool/result', data: {} } }, assistant('b')]), 'b');
});

test('one chat maps to one session and the mapping survives a restart', async () => {
  const file = await stateFile();
  const calls = [];
  const api = fakeController({ createCalls: calls });
  const relay = createRelay({ ...wiring(api), workspace: 'C:/ws', stateFile: file });
  const first = await relay.handle({ chatKey: 'chat-a', text: '在吗' });
  assert.equal(first, '你好呀');
  assert.equal(calls.length, 1);
  assert.equal(calls[0].cwd, 'C:/ws');
  assert.equal(calls[0].agentPreset, 'whale-relay');
  assert.equal(api.prompts[0].content[0].text, '在吗');
  assert.equal(api.prompts[0].mode, 'queue');

  const second = createRelay({ ...wiring(api), workspace: 'C:/ws', stateFile: file });
  await second.handle({ chatKey: 'chat-a', text: '还在吗' });
  assert.equal(calls.length, 1, 'second turn reuses the stored session');

  const stored = JSON.parse(await readFile(file, 'utf8'));
  assert.equal(Object.keys(stored.sessions).length, 1);
});

test('locks the session permission to read-only before prompting', async () => {
  const applied = [];
  const api = fakeController();
  const relay = createRelay({ ...wiring(api, { permission: fakePermission(applied) }), workspace: 'C:/ws', stateFile: await stateFile() });
  await relay.handle({ chatKey: 'chat-p', text: 'x' });
  assert.equal(applied.length, 1);
  assert.equal(applied[0].name, 'read-only');
});

test('refuses to run when the permission lock is unavailable', async () => {
  const api = fakeController();
  const relay = createRelay({ ...wiring(api, { permission: null, session: null }), workspace: 'C:/ws', stateFile: await stateFile() });
  await assert.rejects(() => relay.handle({ chatKey: 'chat-p', text: 'x' }), (error) => error.code === 'PERMISSION_UNAVAILABLE');
  assert.equal(api.prompts.length, 0, 'no prompt may run without the lock');
});

test('refuses when the permission did not actually change', async () => {
  const api = fakeController();
  const stuck = { set() {}, current() { return 'danger-full-access'; } };
  const relay = createRelay({ ...wiring(api, { permission: stuck }), workspace: 'C:/ws', stateFile: await stateFile() });
  await assert.rejects(() => relay.handle({ chatKey: 'chat-p', text: 'x' }), (error) => error.code === 'PERMISSION_NOT_APPLIED');
  assert.equal(api.prompts.length, 0);
});

test('different chats get different sessions', async () => {
  const calls = [];
  const relay = createRelay({ ...wiring(fakeController({ createCalls: calls })), workspace: 'C:/ws', stateFile: await stateFile() });
  await relay.handle({ chatKey: 'chat-a', text: '1' });
  await relay.handle({ chatKey: 'chat-b', text: '2' });
  assert.equal(calls.length, 2);
  assert.notEqual(calls[0].sessionId, calls[1].sessionId);
});

test('a missing preset fails loudly instead of falling back to a tool-enabled default', async () => {
  const api = fakeController();
  api.create = async () => { throw new Error('unknown preset'); };
  const relay = createRelay({ ...wiring(api), workspace: 'C:/ws', stateFile: await stateFile() });
  await assert.rejects(() => relay.handle({ chatKey: 'c', text: 'x' }), (error) => error.code === 'PRESET_UNAVAILABLE');
});

test('a turn without output times out cleanly', async () => {
  const api = fakeController();
  api.wait = async (_req, signal) => {
    needsSignal('wait')(signal);
    return { reason: 'idle', state: { cursor: 0, running: false }, output: { records: [], truncated: false } };
  };
  const relay = createRelay({ ...wiring(api), workspace: 'C:/ws', stateFile: await stateFile(), timeoutMs: 60 });
  await assert.rejects(() => relay.handle({ chatKey: 'c', text: 'x' }), (error) => error instanceof RelayError && error.code === 'TURN_TIMEOUT');
});

test('input-required aborts instead of guessing', async () => {
  const api = fakeController();
  api.wait = async (_req, signal) => {
    needsSignal('wait')(signal);
    return { reason: 'input-required', state: { cursor: 0, running: true }, output: { records: [], truncated: false } };
  };
  const relay = createRelay({ ...wiring(api), workspace: 'C:/ws', stateFile: await stateFile() });
  await assert.rejects(() => relay.handle({ chatKey: 'c', text: 'x' }), (error) => error.code === 'INPUT_REQUIRED');
});

test('rejects empty text and missing controller', async () => {
  const relay = createRelay({ ...wiring(null), workspace: 'C:/ws', stateFile: await stateFile() });
  await assert.rejects(() => relay.handle({ chatKey: 'c', text: '  ' }), (error) => error.code === 'BAD_TEXT');
  await assert.rejects(() => relay.handle({ chatKey: 'c', text: 'x' }), (error) => error.code === 'NO_CONTROLLER');
});

test('same chat serialises, no overlapping prompts', async () => {
  const api = fakeController();
  const order = [];
  const originalPrompt = api.prompt.bind(api);
  let running = 0;
  api.prompt = async (req, signal) => {
    running += 1;
    order.push('start');
    await new Promise((r) => setTimeout(r, 20));
    order.push('end');
    assert.equal(running, 1);
    running -= 1;
    return originalPrompt(req, signal);
  };
  const relay = createRelay({ ...wiring(api), workspace: 'C:/ws', stateFile: await stateFile() });
  await Promise.all([relay.handle({ chatKey: 'same', text: 'a' }), relay.handle({ chatKey: 'same', text: 'b' })]);
  assert.deepEqual(order, ['start', 'end', 'start', 'end']);
});
