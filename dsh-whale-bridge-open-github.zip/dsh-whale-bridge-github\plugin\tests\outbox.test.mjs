import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp } from 'node:fs/promises';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { createOutbox, splitImageMarkers, extractImageReferences } from '../outbox.mjs';
import { writeFileSync, mkdirSync } from 'node:fs';

const stateFile = async () => join(await mkdtemp(join(tmpdir(), 'outbox-')), 'outbox.json');

function fakeController(events = []) {
  const log = { events };
  const api = {
    cursor: 0,
    async state() { return { cursor: api.cursor, active: true, running: false, queue: null, pendingInput: [] }; },
    async wait({ afterSeq = 0 }) {
      const records = log.events
        .filter((e) => e.seq > afterSeq)
        .map((e) => ({ event: { type: 'assistant/message', seq: e.seq, data: { message: { content: [{ type: 'text', text: e.text }] } } } }));
      api.cursor = Math.max(api.cursor, ...log.events.map((e) => e.seq), 0);
      return { reason: 'idle', state: { cursor: api.cursor, running: false }, output: { records, truncated: false } };
    },
    say(text) {
      api.cursor += 1;
      log.events.push({ seq: api.cursor, text });
    },
  };
  return api;
}

const mappings = (sessionId, chatId) => async () => [{ chatKey: `acct|wechat|private|${chatId}`, chatId, sessionId }];

test('queues assistant text produced outside a relay turn', async () => {
  const api = fakeController();
  const box = createOutbox({ getController: () => api, getMappings: mappings('s1', 'chat-1'), stateFile: await stateFile() });
  await box.start();
  box.stop();
  api.say('主动问候');
  await box.scan();
  const items = box.list();
  assert.equal(items.length, 1);
  assert.equal(items[0].chatId, 'chat-1');
  assert.equal(items[0].text, '主动问候');
});

test('relay reply is excluded via markTurn', async () => {
  const api = fakeController();
  const box = createOutbox({ getController: () => api, getMappings: mappings('s1', 'chat-1'), stateFile: await stateFile() });
  await box.start();
  box.stop();
  api.say('这是桥接的回复');
  await box.markTurn('s1', api.cursor);
  await box.scan();
  assert.equal(box.list().length, 0);
});

test('history before start is never replayed', async () => {
  const api = fakeController();
  api.say('很久以前的一句话');
  const box = createOutbox({ getController: () => api, getMappings: mappings('s1', 'chat-1'), stateFile: await stateFile() });
  await box.start();
  box.stop();
  await box.scan();
  assert.equal(box.list().length, 0);
});

test('busy sessions are skipped', async () => {
  const api = fakeController();
  const box = createOutbox({
    getController: () => api, getMappings: mappings('s1', 'chat-1'), isBusy: () => true, stateFile: await stateFile(),
  });
  await box.start();
  box.stop();
  api.say('正在处理中');
  await box.scan();
  assert.equal(box.list().length, 0);
});

test('ack removes items and duplicates are suppressed', async () => {
  const api = fakeController();
  const box = createOutbox({ getController: () => api, getMappings: mappings('s1', 'chat-1'), stateFile: await stateFile() });
  await box.start();
  box.stop();
  await box.enqueue('chat-1', '同一句');
  await box.enqueue('chat-1', '同一句');
  assert.equal(box.list().length, 1);
  const removed = await box.ack(box.list().map((i) => i.id));
  assert.equal(removed, 1);
  assert.equal(box.list().length, 0);
});

test('queue survives a restart', async () => {
  const file = await stateFile();
  const api = fakeController();
  const first = createOutbox({ getController: () => api, getMappings: mappings('s1', 'chat-1'), stateFile: file });
  await first.start();
  first.stop();
  await first.enqueue('chat-1', '重启后还要发');
  const second = createOutbox({ getController: () => api, getMappings: mappings('s1', 'chat-1'), stateFile: file });
  await second.start();
  second.stop();
  assert.equal(second.list().length, 1);
  assert.equal(second.list()[0].text, '重启后还要发');
});

test('image markers inside the workspace are extracted and the text is stripped', async () => {
  const ws = await mkdtemp(join(tmpdir(), 'ws-'));
  const file = join(ws, 'shot.png');
  writeFileSync(file, Buffer.from([0x89, 0x50, 0x4e, 0x47]));
  const parsed = splitImageMarkers('看图\n[[image: ' + file + ']]\n好看吗', ws);
  assert.equal(parsed.images.length, 1);
  assert.equal(parsed.images[0], file);
  assert.equal(parsed.text, '看图\n\n好看吗');
});

test('images outside the workspace or with wrong extensions are dropped', async () => {
  const ws = await mkdtemp(join(tmpdir(), 'ws-'));
  const outside = join(await mkdtemp(join(tmpdir(), 'other-')), 'x.png');
  writeFileSync(outside, Buffer.from([0x89, 0x50, 0x4e, 0x47]));
  const insideTxt = join(ws, 'notes.txt');
  writeFileSync(insideTxt, 'hello');
  const parsed = splitImageMarkers('[[image: ' + outside + ']] [[image: ' + insideTxt + ']]', ws);
  assert.equal(parsed.images.length, 0);
  assert.equal(parsed.text, '');
});

test('a marked image reaches the queue as an image item', async () => {
  const ws = await mkdtemp(join(tmpdir(), 'ws-'));
  const file = join(ws, 'pic.webp');
  writeFileSync(file, Buffer.from([1, 2, 3, 4]));
  const api = fakeController();
  const box = createOutbox({
    getController: () => api, getMappings: mappings('s1', 'chat-1'), workspace: ws, stateFile: await stateFile(),
  });
  await box.start();
  box.stop();
  api.say('发你一张 [[image: ' + file + ']]');
  await box.scan();
  const items = box.list();
  assert.equal(items.length, 2);
  const image = items.find((row) => row.kind === 'image');
  const text = items.find((row) => row.kind === 'text');
  assert.equal(image.file, file);
  assert.equal(text.text, '发你一张');
});
test('an extra image root is trusted, other outside paths are not', async () => {
  const ws = await mkdtemp(join(tmpdir(), 'ws-'));
  const pack = await mkdtemp(join(tmpdir(), 'pack-'));
  const meme = join(pack, 'm.jpg');
  writeFileSync(meme, Buffer.from([0xff, 0xd8, 0xff]));
  const stranger = join(await mkdtemp(join(tmpdir(), 'x-')), 'y.png');
  writeFileSync(stranger, Buffer.from([0x89, 0x50]));
  const ok = splitImageMarkers('[[image: ' + meme + ']]', ws, [pack]);
  assert.equal(ok.images.length, 1);
  assert.equal(ok.images[0], meme);
  const bad = splitImageMarkers('[[image: ' + stranger + ']]', ws, [pack]);
  assert.equal(bad.images.length, 0);
});
test('bare image paths (what the meme tool emits) are converted to images', async () => {
  const ws = await mkdtemp(join(tmpdir(), 'ws-'));
  const pack = await mkdtemp(join(tmpdir(), 'pack-'));
  const meme = join(pack, 'deyi.jpg');
  writeFileSync(meme, Buffer.from([0xff, 0xd8, 0xff]));
  const parsed = extractImageReferences('给你看 ' + meme + ' 可爱吧', ws, [pack]);
  assert.equal(parsed.images.length, 1);
  assert.equal(parsed.images[0], meme);
  assert.equal(parsed.text, '给你看  可爱吧');
});

test('markdown and file:// image references are converted too', async () => {
  const ws = await mkdtemp(join(tmpdir(), 'ws-'));
  const a = join(ws, 'a.png');
  const b = join(ws, 'b.webp');
  writeFileSync(a, Buffer.from([0x89, 0x50]));
  writeFileSync(b, Buffer.from([1, 2, 3]));
  const md = extractImageReferences('看 ![图](' + a + ')', ws);
  assert.deepEqual(md.images, [a]);
  const url = extractImageReferences('file:///' + b.replace(/\\/g, '/'), ws);
  assert.equal(url.images.length, 1);
});

test('a bare path outside the trusted roots stays as text and is not queued', async () => {
  const ws = await mkdtemp(join(tmpdir(), 'ws-'));
  const stranger = join(await mkdtemp(join(tmpdir(), 'x-')), 'secret.png');
  writeFileSync(stranger, Buffer.from([0x89, 0x50]));
  const parsed = extractImageReferences('这是 ' + stranger + ' 路径', ws);
  assert.equal(parsed.images.length, 0);
  assert.match(parsed.text, /secret\.png/);
});
test('native [表情: 描述] markers resolve through the meme pack index', async () => {
  const { DatabaseSync } = await import('node:sqlite');
  const ws = await mkdtemp(join(tmpdir(), 'ws-'));
  const root = await mkdtemp(join(tmpdir(), 'memes-'));
  const pack = join(root, 'pack-1');
  mkdirSync(join(pack, 'memes', 'happy'), { recursive: true });
  const file = join(pack, 'memes', 'happy', 'deyi.jpg');
  writeFileSync(file, Buffer.from([0xff, 0xd8, 0xff]));
  const db = new DatabaseSync(join(pack, 'index.db'));
  db.exec('CREATE TABLE memes (path TEXT, tag TEXT, file_name TEXT, file_hash TEXT, caption TEXT, keywords TEXT, mtime REAL, captioned_at REAL)');
  db.prepare('INSERT INTO memes (path, tag, file_name, caption, keywords) VALUES (?, ?, ?, ?, ?)')
    .run('memes/happy/deyi.jpg', 'happy', 'deyi.jpg', '得意闭眼拳头，好耶，小鲸鱼娘很满意', '得意 好耶 满意 拳头');
  db.close();

  const parsed = extractImageReferences('好耶 [表情: 得意闭眼拳头，好耶，小鲸鱼娘很满意]', ws, [root]);
  assert.equal(parsed.images.length, 1);
  assert.equal(parsed.images[0], file);
  assert.equal(parsed.text, '好耶');
});

test('an unknown meme caption is left as text', async () => {
  const ws = await mkdtemp(join(tmpdir(), 'ws-'));
  const root = await mkdtemp(join(tmpdir(), 'memes-'));
  const parsed = extractImageReferences('嗯 [表情: 不存在的图]', ws, [root]);
  assert.equal(parsed.images.length, 0);
  assert.match(parsed.text, /不存在的图/);
});