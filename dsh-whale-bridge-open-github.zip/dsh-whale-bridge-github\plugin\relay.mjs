/**
 * In-process relay: one WeChat conversation ⇄ one DSH Session in the user's
 * workspace, driven through the Host `sessionController` service.
 *
 * WHY THIS EXISTS: the ACP adapter runs a second, isolated DSH. Its sessions are
 * written by another process, so the running app never notices them; they only
 * appear in the sidebar after a restart. Relaying through the Host controller
 * creates the Session *inside* the running app, which is what makes it live in
 * the sidebar and resumable there.
 *
 * SAFETY RULES (data safety is the point of this module):
 * - We only ever create sessions, and only with ids this module minted itself.
 *   No delete, no rename, no fork, no touching a session id we do not own.
 * - Every session is created with `cwd` fixed to one configured workspace.
 * - A chat maps to exactly one session, persisted, so a restart resumes instead
 *   of piling up new sessions.
 * - Turns for the same chat are serialised; different chats may run in parallel
 *   up to `maxConcurrent`.
 * - Any failure aborts that one turn and reports an error. Nothing is retried
 *   destructively and no other session is affected.
 */
import { randomUUID } from 'node:crypto';
import { readFile, writeFile, mkdir, rename } from 'node:fs/promises';
import { dirname } from 'node:path';

export class RelayError extends Error {
  constructor(status, code, message) {
    super(message);
    this.status = status;
    this.code = code;
  }
}

/** Pull assistant-visible text out of one durable `assistant/message` event. */
export function assistantTextFromEvent(event) {
  const data = event?.data;
  if (!data || typeof data !== 'object') return '';
  if (data.interrupted === true) return '';
  const content = data.message?.content;
  if (typeof content === 'string') return content.trim();
  if (!Array.isArray(content)) return '';
  const parts = [];
  for (const part of content) {
    if (!part || typeof part !== 'object') continue;
    if (part.type === 'text' && typeof part.text === 'string') parts.push(part.text);
  }
  return parts.join('').trim();
}

/**
 * Last assistant message in a wait() page, skipping empty and interrupted ones.
 * `records` are SessionEventEntry values: `{ event: { type, data, seq } }`.
 */
export function lastAssistantText(records) {
  if (!Array.isArray(records)) return '';
  for (let i = records.length - 1; i >= 0; i -= 1) {
    const event = records[i]?.event ?? records[i];
    if (!event || event.type !== 'assistant/message') continue;
    const text = assistantTextFromEvent(event);
    if (text) return text;
  }
  return '';
}

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

/** One chat → one session, persisted so restarts resume the same conversation. */
class SessionMap {
  constructor(file) {
    this.file = file;
    this.loaded = null;
    this.entries = {};
    this.writing = Promise.resolve();
  }

  async load() {
    if (this.loaded) return this.loaded;
    try {
      const raw = JSON.parse(await readFile(this.file, 'utf8'));
      this.entries = raw && typeof raw.sessions === 'object' ? raw.sessions : {};
    } catch { this.entries = {}; }
    this.loaded = this.entries;
    return this.loaded;
  }

  async get(chatKey) {
    await this.load();
    return this.entries[chatKey]?.sessionId ?? null;
  }

  async set(chatKey, sessionId) {
    await this.load();
    this.entries[chatKey] = { sessionId, at: new Date().toISOString() };
    const snapshot = { sessions: this.entries };
    this.writing = this.writing.then(async () => {
      await mkdir(dirname(this.file), { recursive: true });
      const temp = this.file + '.tmp-' + randomUUID();
      await writeFile(temp, JSON.stringify(snapshot, null, 2) + '\n', { encoding: 'utf8', mode: 0o600 });
      await rename(temp, this.file);
    }).catch(() => {});
    await this.writing;
  }
}

export function createRelay({
  getController,
  getPermission = () => undefined,
  getSession = () => undefined,
  onTurn = null,
  workspace,
  stateFile,
  preset = 'whale-relay',
  permissionPreset = 'read-only',
  timeoutMs = 45000,
  maxConcurrent = 2,
  logger = () => {},
}) {
  if (!workspace) throw new RelayError(500, 'NO_WORKSPACE', 'relay 需要配置工作区');
  const sessions = new SessionMap(stateFile);
  const chatChains = new Map();
  let active = 0;
  const waiters = [];

  const controller = () => {
    const value = getController?.();
    if (!value || typeof value.create !== 'function' || typeof value.prompt !== 'function' || typeof value.wait !== 'function') {
      throw new RelayError(503, 'NO_CONTROLLER', '当前宿主没有 sessionController，无法在主进程里跑对话');
    }
    return value;
  };

  async function gate() {
    if (active < maxConcurrent) { active += 1; return () => { active -= 1; const next = waiters.shift(); if (next) next(); }; }
    await new Promise((resolve) => waiters.push(resolve));
    return gate();
  }

  /** Create the session for a chat, or reuse the one already mapped to it. */
  async function ensureSession(chatKey) {
    const known = await sessions.get(chatKey);
    if (known) return known;
    const api = controller();
    const sessionId = 'session-' + randomUUID();
    let created;
    try {
      created = await api.create({ cwd: workspace, sessionId, agentPreset: preset });
    } catch (error) {
      // Deliberately NO fallback to the deployment default: that default may ship
      // tools, and an external chat must never inherit them. Failing loudly is the
      // safe outcome — the transport falls back to her own model instead.
      throw new RelayError(503, 'PRESET_UNAVAILABLE', `无法用预设 "${preset}" 新建会话（${String(error?.message ?? error)}）；为安全起见不退回默认预设`);
    }
    const id = created?.sessionId ?? sessionId;
    await sessions.set(chatKey, id);
    logger('[relay] new session ' + id + ' preset=' + (created?.agentPreset ?? preset) + ' chat=' + chatKey.slice(0, 8));
    return id;
  }

  /** Wait until the turn settles, bounded, and return its assistant text. */
  async function collect(api, sessionId, afterSeq, deadline, signal) {
    let cursor = afterSeq;
    while (Date.now() < deadline) {
      const remaining = Math.max(1000, deadline - Date.now());
      const result = await api.wait({ sessionId, timeoutMs: Math.min(remaining, 15000), ...(cursor === undefined ? {} : { afterSeq: cursor }) }, signal);
      const text = lastAssistantText(result?.output?.records);
      if (text) return text;
      if (result?.reason === 'input-required') {
        throw new RelayError(409, 'INPUT_REQUIRED', '这一轮需要人工确认（可能是工具或权限请求），微信侧无法代答');
      }
      const state = result?.state;
      if (state && typeof state.cursor === 'number') cursor = state.cursor;
      if (!state?.running && result?.reason === 'idle') {
        // No output and idle: the turn may not have started yet. Give it a moment.
        await sleep(250);
      }
    }
    throw new RelayError(504, 'TURN_TIMEOUT', '主进程里这一轮超时了');
  }

  /**
   * Pin the session's permission to the configured preset before every turn.
   *
   * WHY THIS IS MANDATORY: this DSH mounts tool plugins on the host plane, so
   * every agent — whatever its preset — can see them. A preset alone therefore
   * cannot make an external chat harmless. What we CAN do is force the weakest
   * permission (default `read-only` + `ask`) on the session itself: writes and
   * shell commands then need an approval someone has to click, and a turn with
   * nobody around just times out instead of acting.
   *
   * If the lock cannot be applied, the turn is refused. Never "run anyway".
   */
  async function lockPermission(api, sessionId) {
    const permission = getPermission?.();
    if (!permission || typeof permission.set !== 'function' || typeof permission.current !== 'function') {
      throw new RelayError(503, 'PERMISSION_UNAVAILABLE', '拿不到 permissionPresets 服务，无法锁定只读权限，拒绝运行');
    }
    // A resumed cold session has no live object yet; resolveAgent attaches it
    // (or reports why it cannot), and only then can the permission be pinned.
    let session = getSession?.(sessionId) ?? null;
    if (!session && typeof api.resolveAgent === 'function') {
      const resolved = await api.resolveAgent(sessionId).catch(() => null);
      session = resolved?.agent?.session ?? resolved?.session ?? null;
    }
    if (!session) {
      throw new RelayError(503, 'SESSION_NOT_LIVE', '会话无法附着，设不了权限，拒绝运行');
    }
    permission.set(session, permissionPreset);
    const now = permission.current(session);
    if (now !== permissionPreset) {
      throw new RelayError(503, 'PERMISSION_NOT_APPLIED', `权限未能切到 ${permissionPreset}（当前 ${String(now)}），拒绝运行`);
    }
    return now;
  }

  const busy = new Set();

  async function runTurn(chatKey, text) {
    const api = controller();
    const sessionId = await ensureSession(chatKey);
    busy.add(sessionId);
    // Lock before the prompt so the turn starts under the weakest permission.
    const permission = await lockPermission(api, sessionId);
    logger('[relay] permission=' + permission + ' session=' + sessionId);
    // The Host controller API takes a required AbortSignal on every read/prompt
    // call and aborts the request when it fires.
    const ac = new AbortController();
    const before = typeof api.state === 'function'
      ? await api.state({ sessionId }, ac.signal).catch(() => null)
      : null;
    const afterSeq = typeof before?.cursor === 'number' ? before.cursor : undefined;
    const requestId = 'wechat-' + randomUUID();
    await api.prompt({ requestId, sessionId, mode: 'queue', content: [{ type: 'text', text }] }, ac.signal);
    const deadline = Date.now() + timeoutMs;
    try {
      const reply = await collect(api, sessionId, afterSeq, deadline, ac.signal);
      // Tell the outbox where this turn ended so its reply is never re-sent to
      // WeChat as if it were a proactive message.
      if (onTurn) {
        const after = await api.state({ sessionId }, ac.signal).catch(() => null);
        await Promise.resolve(onTurn(sessionId, after?.cursor)).catch(() => {});
      }
      return reply;
    } catch (error) {
      try { ac.abort(); } catch { /* already aborted */ }
      try { api.cancel?.({ sessionId }); } catch { /* best effort only */ }
      throw error;
    } finally {
      busy.delete(sessionId);
    }
  }

  return {
    workspace,
    isBusy: (sessionId) => busy.has(sessionId),
    /** chatKey → chatId + sessionId, for the outbound queue and diagnostics. */
    async mappings() {
      await sessions.load();
      return Object.entries(sessions.entries).map(([chatKey, value]) => ({
        chatKey,
        chatId: String(chatKey).split('|')[3] ?? '',
        sessionId: value?.sessionId ?? '',
      })).filter((row) => row.chatId && row.sessionId);
    },
    async handle({ chatKey, text }) {
      if (typeof chatKey !== 'string' || !chatKey) throw new RelayError(400, 'BAD_CHAT', '缺少会话标识');
      if (typeof text !== 'string' || !text.trim()) throw new RelayError(400, 'BAD_TEXT', '缺少正文');
      const release = await gate();
      const previous = chatChains.get(chatKey) ?? Promise.resolve();
      const run = previous.catch(() => {}).then(() => runTurn(chatKey, text));
      const tail = run.catch(() => {});
      chatChains.set(chatKey, tail);
      tail.then(() => { if (chatChains.get(chatKey) === tail) chatChains.delete(chatKey); });
      try {
        return await run;
      } finally {
        release();
      }
    },
    sessions,
  };
}
