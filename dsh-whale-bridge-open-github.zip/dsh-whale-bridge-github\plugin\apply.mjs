/**
 * Real DSH host entry for dsh-whale-bridge.
 *
 * `apply(ctx)` is what DeepSeek Harness calls when the plugin loads. It registers
 * the settings routes and owns the bridge process, so the user never opens a
 * terminal: one switch in the settings page starts or stops it.
 *
 * WHY THE BRIDGE STAYS A CHILD PROCESS: the listener, the ACP client and the
 * memory store all live in a separate node process. A bug there can be restarted
 * by the supervisor; the same bug inside DSH's own process could take the whole
 * app down, and the user's one hard rule is that the daily DSH must not die.
 *
 * WHAT IS IN THIS PROCESS: only the settings API, the engine that validates
 * config, and the supervisor handle. No port is bound here.
 */
import { readFile, writeFile, mkdir, rename } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { existsSync, readFileSync, writeFileSync, mkdirSync, readdirSync } from 'node:fs';
import { homedir } from 'node:os';
import { randomBytes } from 'node:crypto';
import { jsonStore } from '../src/settings-store.mjs';
import { fileURLToPath } from 'node:url';
import { BridgeEngine, PersonaResolver, normalizeConfig } from '../src/core.mjs';
import { Diagnostics } from '../src/diagnostics.mjs';
import { MemoryStore } from '../src/memory.mjs';
import { BridgeSupervisor } from '../src/supervisor.mjs';
import { createHostAdapter } from './index.js';
import { createRelay } from './relay.mjs';
import { createOutbox, extractImageReferences } from './outbox.mjs';
import { decodeEnvelope } from '../src/envelope.mjs';
import { runSelfcheck } from '../scripts/selfcheck-core.mjs';
import { migrateStateDir, stateDir } from '../src/state-dir.mjs';

const PROJECT_ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const ROUTE = '/plugins/dsh-whale-bridge';
// State lives in the user's home, not inside the package: an update replaces
// node_modules and used to take the model settings and memory with it.
const STATE_DIR = stateDir(PROJECT_ROOT);
// The isolated home MUST live inside the "project" root: assertIsolatedHome
// refuses anything outside it, which is what keeps the daily profile untouchable.
// STATE_DIR is passed as that root, so the guard stays strict while the storage
// itself sits outside node_modules.
const DEFAULT_DSH_HOME = join(STATE_DIR, 'dsh');
const KEY_ENV = 'WHALE_BRIDGE_LLM_KEY';

export const name = 'dsh-whale-bridge';
export const inject = ['webServer'];

/**
 * Writes the model the user picked into the ISOLATED profile.
 *
 * Why not share the daily config: the bridge runs its own DSH process, and DSH
 * model selection is per-profile. A second process has no session to inherit a
 * model from, so "just reuse it" is not a thing that exists. Typing one key here
 * is the honest version of that.
 *
 * The key itself never lands in this file: it goes to the child through an env
 * var that src/isolation.mjs only passes because the name matches the KEY rule.
 */
async function writeModelConfig({ dshHome, baseUrl, model, reasoningEffort }) {
  const dir = join(dshHome, 'profiles', 'acp');
  await mkdir(dir, { recursive: true });
  const quote = (value) => JSON.stringify(String(value));
  const yaml = [
    '# 由 dsh-whale-bridge 生成：隔离宿主的模型配置。改设置页会重写这个文件。',
    '- id: llm-pi-ai',
    '  name: "@deepseek-ai/dsh-llm-pi-ai"',
    '  config:',
    '    providers:',
    '      whale-bridge:',
    '        displayName: 鲸鲸桥接',
    `        apiKeyEnv: ${KEY_ENV}`,
    '        api: openai-completions',
    `        baseURL: ${quote(baseUrl)}`,
    '        models:',
    `          - id: ${quote(model)}`,
    `            name: ${quote(model)}`,
    // THIS BLOCK IS THE ONE THAT MATTERS FOR A BRIDGE TURN.
    // `@deepseek-ai/dsh-acp-app/cordis.patch.yml` inserts its own `id: acp` entry
    // pinned to provider `deepseek-official` / model `deepseek-v4-flash`, and
    // `dsh-acp/lib/index.js` reads the session model from THAT entry only:
    // `session/new` passes `agentOptions(config)` built from it, and the ACP
    // `Config` has no reasoningEffort at all.
    //
    // Leaving it out (which this file used to do) meant every setting on the
    // models page was decorative: turns really went to deepseek-official and only
    // worked because the launcher injected DEEPSEEK_API_KEY as well. Proof: with
    // no key in the environment the first turn failed with
    // `no API key for provider route "deepseek-official"`.
    '- id: acp',
    '  name: "@deepseek-ai/dsh-acp"',
    '  config:',
    '    provider: whale-bridge',
    `    model: ${quote(model)}`,
    '- id: agent-default-model',
    '  name: "@deepseek-ai/dsh-agent-default-model"',
    '  config:',
    '    provider: whale-bridge',
    `    model: ${quote(model)}`,
    `    reasoningEffort: ${quote(reasoningEffort)}`,
    '',
  ].join('\n');
  await writeFile(join(dir, 'cordis.patch.yml'), yaml, 'utf8');
  return join(dir, 'cordis.patch.yml');
}

/** The loopback token 鲸鲸 must send; minted here when no child ever wrote one. */
function readBridgeToken() {
  try { return readFileSync(join(STATE_DIR, 'bridge-token.txt'), 'utf8').trim(); }
  catch { return ''; }
}

function ensureBridgeToken() {
  const existing = readBridgeToken();
  if (existing) return existing;
  const token = randomBytes(24).toString('hex');
  try {
    mkdirSync(STATE_DIR, { recursive: true });
    writeFileSync(join(STATE_DIR, 'bridge-token.txt'), token + '\n', { encoding: 'utf8', mode: 0o600 });
  } catch { /* a read-only state dir still leaves a usable in-memory token */ }
  return token;
}

/**
 * Where 鲸鲸 keeps its plugin data. Env first, then the path we cached when the
 * auto-discovery failed once, then the two standard per-user install locations.
 */
function whaleDataCandidates() {
  const out = [];
  const explicit = String(process.env.WHALE_DATA_DIR || '').trim();
  if (explicit) out.push(explicit);
  try {
    const cached = JSON.parse(readFileSync(join(STATE_DIR, 'whale-path.json'), 'utf8'));
    if (cached?.dataDir) out.push(cached.dataDir);
  } catch { /* not cached yet */ }
  if (process.env.LOCALAPPDATA) {
    out.push(join(process.env.LOCALAPPDATA, 'Programs', 'WhaleGirl', 'data'));
    out.push(join(process.env.LOCALAPPDATA, 'WhaleGirl', 'data'));
  }
  if (process.env.APPDATA) out.push(join(process.env.APPDATA, 'WhaleGirl', 'data'));
  return out;
}

/**
 * Write the relay address + token into the Whale plugin's own config.
 *
 * Only that one file is touched, and only the keys the bridge owns. The daily
 * DSH profile is never involved. Failure is logged, never fatal: a wrong
 * pointer costs replies, not the bridge.
 */
async function syncWhaleEndpoint(url, token) {
  if (!url || !token) return;
  const dataDir = whaleDataCandidates().find((dir) => existsSync(join(dir, 'plugins')));
  if (!dataDir) return;
  const dir = join(dataDir, 'plugins', 'whale-dsh-bridge.data');
  const file = join(dir, 'config.json');
  let current = {};
  try { current = JSON.parse(await readFile(file, 'utf8')); } catch { /* first run */ }
  const next = { enabled: true, timeoutMs: 40000, ...current, url, token };
  await mkdir(dir, { recursive: true });
  const temp = file + '.tmp-' + process.pid;
  await writeFile(temp, JSON.stringify(next, null, 2) + '\n', 'utf8');
  await rename(temp, file);
  try {
    await writeFile(join(STATE_DIR, 'whale-path.json'), JSON.stringify({ dataDir }, null, 2) + '\n', 'utf8');
  } catch { /* cache is optional */ }
}

/**
 * Extra directories the outbound image queue may read from.
 *
 * The relay workspace is always allowed; these are the trusted asset roots. The
 * meme plugin keeps its packs under <profile>/node_modules/dsh-meme/memes, which
 * is outside the workspace by design, so it has to be listed here explicitly.
 * Anything not under one of these roots is dropped, never sent.
 */
function collectImageRoots(cfg = {}) {
  const roots = [];
  for (const dir of Array.isArray(cfg?.imageRoots) ? cfg.imageRoots : []) {
    if (typeof dir === 'string' && dir.trim()) roots.push(dir.trim());
  }
  const profileDir = String(process.env.DSH_PROFILE_DIR || '').trim();
  if (profileDir) roots.push(join(profileDir, 'node_modules', 'dsh-meme', 'memes'));
  // The host process does not always carry DSH_PROFILE_DIR; scan the profile tree
  // for the meme plugin's pack directory instead of hard-coding one profile.
  try {
    const profilesRoot = join(homedir(), '.dsh', 'profiles');
    for (const name of readdirSync(profilesRoot)) {
      roots.push(join(profilesRoot, name, 'node_modules', 'dsh-meme', 'memes'));
    }
  } catch { /* no profiles tree */ }
  return roots.filter((dir) => { try { return existsSync(dir); } catch { return false; } });
}

function readBody(req, limit = 256 * 1024) {  return new Promise((resolve) => {
    let raw = '';
    req.on('data', (chunk) => { raw += chunk; if (raw.length > limit) raw = raw.slice(0, limit); });
    req.on('end', () => { try { resolve(raw ? JSON.parse(raw) : {}); } catch { resolve({}); } });
    req.on('error', () => resolve({}));
  });
}

function send(res, status, payload) {
  const body = JSON.stringify(payload ?? {});
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'content-length': Buffer.byteLength(body) });
  res.end(body);
}

export function apply(ctx) {
  // Bring old state across on first start after the folder moved out of the
  // package. Fire-and-forget: a failed copy must never stop the plugin from
  // loading, and the old folder stays readable either way.
  migrateStateDir(PROJECT_ROOT).then((result) => {
    if (result.moved) console.log('[whale-bridge] state moved out of the package: ' + result.from + ' -> ' + result.to);
    else if (result.reason === 'copy-failed') console.warn('[whale-bridge] state copy failed: ' + result.error);
  }).catch(() => {});
  const state = jsonStore(join(STATE_DIR, 'service.json'), {
    enabled: false, autoStart: false, timeoutMs: 40000,
    adapter: 'mock', model: 'deepseek-flash', reasoningEffort: 'low', relay: false, workspace: '', relayPreset: 'whale-relay', relayPermission: 'read-only',
    baseUrl: 'https://api.deepseek.com', apiKey: '', dshHome: DEFAULT_DSH_HOME,
  });
  // Persona settings need their own file. They used to live in memory only, so a
  // DSH restart silently reset "follow Whale-Girl" back to the placeholder text and
  // the replies went generic — the exact symptom that looks like "the persona did
  // not take effect".
  const configStore = jsonStore(join(STATE_DIR, 'config.json'), {
    enabled: false,
    personaSource: 'whale',
    customPrompt: '',
  });
  // apply() is synchronous, so the saved settings are read synchronously here and
  // handed to both the store and the engine. The store keeps them in sync later.
  let savedConfig = null;
  try {
    savedConfig = JSON.parse(readFileSync(join(STATE_DIR, 'config.json'), 'utf8'));
  } catch { /* first run: defaults below */ }
  const diagnostics = new Diagnostics({ directory: join(STATE_DIR, 'logs') });
  const memory = new MemoryStore({ root: join(STATE_DIR, 'memory') });
  const engine = new BridgeEngine({
    adapter: { kind: 'delegated', async generate() { throw new Error('桥接在独立进程里，这里不直接生成'); } },
    personas: new PersonaResolver({
      readDshPersona: async () => { throw new Error('DSH 人格来源未接线'); },
      readWhalePersona: async () => { throw new Error('鲸鲸人格走请求内 system'); },
    }),
    // Start from whatever the user last saved; the placeholder only fills a gap on
    // a brand-new install. An empty prompt is rejected by normalizeConfig, and a
    // throw here would take the whole plugin down at load time.
    config: {
      enabled: false,
      personaSource: 'whale',
      customPrompt: '（还没设置人格来源，请到设置页选一项）',
      ...(savedConfig && typeof savedConfig === 'object' ? savedConfig : {}),
    },
  });
  const supervisor = new BridgeSupervisor({ projectRoot: PROJECT_ROOT, onEvent: () => {} });

  /** Build the child environment from the saved settings, every time it starts. */
  /**
   * Find the `dsh` launcher that starts the ACP child.
   *
   * Why this exists: the bridge spawns `cmd /c <launcher dir>\dsh.cmd --profile acp`.
   * With no launcher it just runs `dsh.cmd` and hopes PATH has it — which is false
   * on a normal install, so the child exits with code 1 and every message falls
   * back to the echo adapter. Deriving it from the running app is the only way that
   * works on someone else's machine.
   *
   * Order: explicit override → the app's own resources → a nearby node_modules/.bin
   * → nothing (let PATH decide).
   */
  function findLauncher() {
    const override = String(process.env.WHALE_BRIDGE_DSH_LAUNCHER || '').trim();
    if (override) return override;
    const candidates = [];
    const exe = process.execPath || '';
    if (exe) {
      const appDir = dirname(exe);
      // Packaged desktop app: <install>/resources/runtime/cli/bin/dsh.cmd
      candidates.push(join(appDir, 'resources', 'runtime', 'cli', 'bin'));
      // Dev checkout: <checkout>/node_modules/.bin/dsh.cmd
      candidates.push(join(appDir, 'node_modules', '.bin'));
      // One level up (app sits in a subfolder of the install root).
      candidates.push(join(appDir, '..', 'resources', 'runtime', 'cli', 'bin'));
    }
    for (const dir of candidates) {
      try { if (existsSync(join(dir, 'dsh.cmd'))) return dir; } catch { /* try next */ }
    }
    return '';
  }

  async function supervisorEnv() {
    const cfg = await state.load();
    const env = { WHALE_BRIDGE_ADAPTER: cfg.adapter || 'mock' };
    if (env.WHALE_BRIDGE_ADAPTER === 'acp') {
      env.WHALE_BRIDGE_DSH_HOME = cfg.dshHome || DEFAULT_DSH_HOME;
      env.WHALE_BRIDGE_MODEL = cfg.model || 'deepseek-flash';
      env.WHALE_BRIDGE_EFFORT = cfg.reasoningEffort || 'low';
      // The name MUST match what scripts/wire-host.mjs reads. It used to be written
      // as WHALE_BRIDGE_LAUNCHER and read as WHALE_BRIDGE_DSH_LAUNCHER, so the child
      // always got an empty value no matter what the settings page said.
      env.WHALE_BRIDGE_DSH_LAUNCHER = findLauncher();
      if (cfg.apiKey) env[KEY_ENV] = cfg.apiKey;
    }
    return env;
  }

  const adapter = createHostAdapter({
    bridge: engine,
    store: configStore,
    onConfigChanged: async (next, previous) => {
      const changed = ['personaSource', 'customPrompt', 'customPersona'].some((key) => JSON.stringify(next[key]) !== JSON.stringify(previous[key]));
      if (changed && supervisor.status().running) {
        await supervisor.stop();
        await supervisor.start({ env: await supervisorEnv() });
      }
    },
    diagnostics,
    memory,
    supervisor,
    serviceStore: state,
    // Written by the child on start-up; read here so the panel can show what the
    // plugin sync actually did without dressing it up as an error.
    readSync: async () => {
      try { return JSON.parse(await readFile(join(STATE_DIR, 'last-sync.json'), 'utf8')); } catch { return null; }
    },
    selfcheck: () => runSelfcheck({ projectRoot: PROJECT_ROOT }),
    // Called by the settings route whenever the model settings change, and again
    // right before the child starts, so the isolated profile always matches the UI.
    prepareModel: async (cfg) => {
      if ((cfg.adapter || 'mock') !== 'acp') return null;
      if (!cfg.apiKey) return { ok: false, reason: '还没有填 API Key' };
      return writeModelConfig({
        dshHome: cfg.dshHome || DEFAULT_DSH_HOME,
        baseUrl: cfg.baseUrl || 'https://api.deepseek.com',
        model: cfg.model || 'deepseek-flash',
        reasoningEffort: cfg.reasoningEffort || 'low',
      }).then((file) => ({ ok: true, file })).catch((e) => ({ ok: false, reason: String(e?.message ?? e) }));
    },
    resolveEnv: supervisorEnv,
    // Relay controls used by the settings page. Errors are reported, never thrown
    // into the route, so a bad workspace cannot take the panel down.
    relayStatus: () => relayCtl.status(),
    applyRelay: async (cfg) => {
      try {
        if (cfg?.relay) {
          await supervisor.stop().catch(() => {});
          return relayCtl.start(cfg);
        }
        relayCtl.stop();
        return { ok: true };
      } catch (error) {
        return { ok: false, reason: String(error?.message ?? error) };
      }
    },
  });

  const webServer = ctx?.webServer ?? ctx?.get?.('webServer');

  // ---- relay mode: the turn runs in THIS process -------------------------
  // Reading service.json synchronously is deliberate: apply() is sync, and the
  // switch has to be honoured before anything spawns a child process.
  let savedService = {};
  try { savedService = JSON.parse(readFileSync(join(STATE_DIR, 'service.json'), 'utf8')); } catch { /* defaults */ }
  const relayEnabled = Boolean(savedService?.relay);
  // Filled in after both exist: the relay reports where each turn ended, and the
  // outbox must not treat that reply as a proactive message.
  const outboxRef = { current: null };

  /**
   * Live controller for relay mode. The settings page can turn it on or off and
   * change its workspace/permission without restarting DSH, so construction is
   * kept here instead of inline at load time.
   */
  const relayCtl = {
    relay: null,
    outbox: null,
    start(cfg = {}) {
      this.stop();
      const workspace = String(cfg?.workspace || '').trim();
      if (!workspace || !existsSync(workspace)) {
        console.warn('[whale-bridge] relay 开启失败：工作区不存在 ' + (workspace || '(未配置)'));
        return { ok: false, reason: 'workspace' };
      }
      this.relay = createRelay({
        getController: () => ctx?.get?.('sessionController') ?? ctx?.sessionController ?? undefined,
        // Host-plane tools are visible to every agent in this DSH, so the real
        // boundary is the session permission: force the weakest preset and let
        // every write/shell action wait for a human approval.
        getPermission: () => ctx?.get?.('permissionPresets') ?? undefined,
        getSession: (id) => {
          // `ctx.sessions` needs a declared inject; `ctx.get` is the safe lookup
          // for a plugin that only optionally uses the service.
          try { return ctx?.get?.('sessions')?.get?.(id); } catch { return undefined; }
        },
        onTurn: (sessionId, cursor) => outboxRef.current?.markTurn(sessionId, cursor),
        permissionPreset: String(cfg?.relayPermission || 'read-only'),
        workspace,
        stateFile: join(STATE_DIR, 'relay-sessions.json'),
        // The preset is the security boundary: it must be the tool-free one this
        // bundle declares (plugin/cordis.patch.yml). Missing preset fails the
        // turn instead of silently using a tool-enabled default.
        preset: String(cfg?.relayPreset || 'whale-relay'),
        // Keep the relay strictly under Whale's own request timeout so the
        // transport never answers after she has already given up.
        timeoutMs: Math.max(5000, Math.min(Number(cfg?.timeoutMs) || 40000, 35000)),
        maxConcurrent: 2,
        logger: (line) => console.log(line),
      });
      const imageRoots = collectImageRoots(cfg);
      this.imageRoots = imageRoots;
      // Outbound: anything committed to a mapped session OUTSIDE a relay turn
      // (speak-up, a scheduled prompt, or the user typing there) is queued for
      // the Whale-side poller to send.
      this.outbox = createOutbox({
        getController: () => ctx?.get?.('sessionController') ?? undefined,
        getMappings: () => this.relay?.mappings() ?? [],
        isBusy: (sessionId) => this.relay?.isBusy(sessionId) ?? false,
        // Images are only accepted from inside these directories.
        workspace,
        imageRoots,
        stateFile: join(STATE_DIR, 'outbox.json'),
        intervalMs: 10000,
        logger: (line) => console.log(line),
      });
      outboxRef.current = this.outbox;
      this.outbox.start().catch((error) => console.warn('[whale-bridge] outbox 启动失败：' + String(error?.message ?? error)));
      publishEndpoint();
      console.log('[whale-bridge] relay 模式：微信对话将作为本进程的会话出现在工作区 ' + workspace);
      return { ok: true };
    },
    stop() {
      try { this.outbox?.stop(); } catch { /* already stopped */ }
      this.outbox = null;
      this.relay = null;
      outboxRef.current = null;
    },
    status() {
      return {
        running: Boolean(this.relay),
        workspace: this.relay?.workspace ?? null,
        imageRoots: this.imageRoots ?? [],
        pending: this.outbox ? this.outbox.list(100).length : 0,
      };
    },
  };

  /** Point 鲸鲸 at this process; retried because the port may not be published yet. */
  const publishEndpoint = (attempt = 0) => {
    const port = Number(webServer?.port ?? webServer?.server?.address?.()?.port ?? 0);
    if (Number.isInteger(port) && port > 0) {
      syncWhaleEndpoint(`http://127.0.0.1:${port}${ROUTE}`, ensureBridgeToken()).catch((error) => {
        console.warn('[whale-bridge] 写入鲸鲸地址失败：' + String(error?.message ?? error));
      });
      return;
    }
    if (attempt < 4) setTimeout(() => publishEndpoint(attempt + 1), 800 + attempt * 700);
    else console.warn('[whale-bridge] 拿不到 web 端口，未改写鲸鲸地址');
  };

  if (relayEnabled) relayCtl.start(savedService);

  if (webServer) {
    // ctx.effect gives the host a disposer, so toggling the plugin off or hot
    // reloading does not collide with an already-registered route.
    ctx.effect(() => webServer.register({
      kind: 'prefix',
      path: ROUTE,
      async handler(req, res) {
        const url = String(req.url || '');
        const pathname = url.split('?')[0];
        // adapter.handle matches FULL paths (ROUTES are absolute), so pass the
        // pathname through instead of stripping the prefix.
        const method = String(req.method || 'GET').toUpperCase();
        try {
          // Cheap liveness probe: proves which build of the host half is loaded.
          if (method === 'GET' && pathname === ROUTE + '/ping') {
            return send(res, 200, { ok: true, pid: process.pid, build: 'relay-2', relay: relayCtl.status().running, workspace: relayCtl.status().workspace, at: Date.now() });
          }
          if (relayCtl.relay && method === 'POST' && pathname === ROUTE + '/v1/chat/completions') {
            return await relayHandler(req, res);
          }
          // ---- outbound queue (polled by the Whale-side plugin) --------------
          if (relayCtl.outbox && pathname.startsWith(ROUTE + '/outbox')) {
            const token = readBridgeToken();
            if (!token || String(req.headers.authorization || '') !== 'Bearer ' + token) {
              return send(res, 401, { ok: false, code: 'UNAUTHORIZED', message: '令牌不正确' });
            }
            if (method === 'GET' && pathname === ROUTE + '/outbox') {
              const limit = Number(new URL(url, 'http://127.0.0.1').searchParams.get('limit') || 20);
              return send(res, 200, { ok: true, items: relayCtl.outbox.list(limit) });
            }
            if (method === 'POST' && pathname === ROUTE + '/outbox/ack') {
              const body = await readBody(req);
              const removed = await relayCtl.outbox.ack(body?.ids);
              return send(res, 200, { ok: true, removed });
            }
            if (method === 'POST' && pathname === ROUTE + '/outbox/test') {
              const body = await readBody(req);
              const chatId = String(body?.chatId || '');
              if (body?.file) {
                // Self-test path for images: route it through the same validation
                // the marker parser uses, so a bad path fails here too.
                const probe = extractImageReferences('[[image: ' + String(body.file) + ']]', relayCtl.status().workspace, relayCtl.imageRoots);
                const item = probe.images.length ? await relayCtl.outbox.enqueueImage(chatId, probe.images[0]) : null;
                return send(res, item ? 200 : 400, item ? { ok: true, item } : { ok: false, code: 'BAD_IMAGE', message: '图片不在工作区、类型不支持或文件不存在' });
              }
              const parsed = extractImageReferences(String(body?.text || ''), relayCtl.status().workspace, relayCtl.imageRoots);
              const created = [];
              if (parsed.text) { const one = await relayCtl.outbox.enqueue(chatId, parsed.text); if (one) created.push(one); }
              for (const file of parsed.images) { const one = await relayCtl.outbox.enqueueImage(chatId, file); if (one) created.push(one); }
              return send(res, created.length ? 200 : 400, created.length ? { ok: true, items: created } : { ok: false, code: 'BAD_ITEM', message: '缺少 chatId 或可识别的图片/文字' });
            }
            if (method === 'POST' && pathname === ROUTE + '/outbox/parse') {
              // Mirrors what the scan does to one assistant message, without a live
              // turn: handy for checking an exact reply before it reaches WeChat.
              const body = await readBody(req);
              const parsed = extractImageReferences(String(body?.text || ''), relayCtl.status().workspace, relayCtl.imageRoots);
              return send(res, 200, { ok: true, text: parsed.text, images: parsed.images });
            }
            return send(res, 404, { ok: false, code: 'NOT_FOUND' });
          }
          if (method === 'GET' && pathname === ROUTE + '/debug/events') {
            // Diagnose what a mapped session actually stored, without opening the
            // session in the UI: types, text, and whether an image part exists.
            const token = readBridgeToken();
            if (!token || String(req.headers.authorization || '') !== 'Bearer ' + token) {
              return send(res, 401, { ok: false, code: 'UNAUTHORIZED' });
            }
            const params = new URL(url, 'http://127.0.0.1').searchParams;
            const sessionId = String(params.get('sessionId') || '');
            if (!sessionId) return send(res, 400, { ok: false, code: 'BAD_SESSION' });
            const controller = ctx?.get?.('sessionController');
            if (!controller?.events) return send(res, 503, { ok: false, code: 'NO_CONTROLLER' });
            const page = await controller.events({ address: { kind: 'session', sessionId }, maxMessages: Number(params.get('max') || 8) }, new AbortController().signal);
            const rows = (page?.records ?? []).map((record) => {
              const event = record?.event ?? record;
              const data = event?.data ?? {};
              const content = data?.message?.content;
              const parts = Array.isArray(content)
                ? content.map((part) => ({ type: part?.type, text: typeof part?.text === 'string' ? part.text.slice(0, 200) : undefined, hasAttachment: Boolean(part?.attachment) }))
                : typeof content === 'string' ? [{ type: 'text', text: content.slice(0, 200) }] : [];
              return { type: event?.type, seq: event?.seq, parts };
            });
            return send(res, 200, { ok: true, sessionId, rows });
          }
          const body = method === 'GET' || method === 'HEAD' ? {} : await readBody(req);
          const result = await adapter.handle(method, pathname, body);
          send(res, 200, result);
        } catch (error) {
          send(res, error?.status ?? 500, { ok: false, code: error?.code ?? 'ERROR', message: String(error?.message ?? error) });
        }
      },
    }));
  }

  // OpenAI-compatible entry for the Whale plugin. Same wire shape as the child
  // proxy, but the work happens here instead of in a second DSH, which is what
  // makes the Session appear in the sidebar without a restart.
  async function relayHandler(req, res) {
    const token = readBridgeToken();
    const auth = String(req.headers.authorization || '');
    if (!token || auth !== 'Bearer ' + token) {
      return send(res, 401, { error: { message: '令牌不正确', type: 'unauthorized' } });
    }
    const body = await readBody(req);
    const messages = Array.isArray(body?.messages) ? body.messages : [];
    const head = messages.find((m) => m && m.role === 'system' && typeof m.content === 'string');
    let meta = null;
    try { meta = decodeEnvelope(head?.content ?? ''); }
    catch { return send(res, 400, { error: { message: '路由信封格式错误', type: 'bad_envelope' } }); }
    if (!meta) return send(res, 400, { error: { message: '缺少路由信封', type: 'bad_envelope' } });
    const lastUser = [...messages].reverse().find((m) => m && m.role === 'user' && typeof m.content === 'string');
    const text = typeof lastUser?.content === 'string' ? lastUser.content : '';
    if (!text.trim()) return send(res, 400, { error: { message: '缺少用户正文', type: 'bad_messages' } });
    // The session keeps its own history, so only the newest line is forwarded.
    const chatKey = [meta.accountId, meta.platform, meta.chatType, meta.chatId].join('|');
    try {
      const reply = await relayCtl.relay.handle({ chatKey, text });
      // A relay reply can carry image markers too (`[表情: …]`, `[[image: …]]`).
      // The outbox scan deliberately skips relay turns, so this is the one place
      // that must split them: pictures go to the outbound queue, the remaining
      // text is what Whale-Girl shows in WeChat. Sending the raw marker as text is
      // exactly what made memes "disappear" here.
      const parsed = extractImageReferences(reply, relayCtl.status().workspace, relayCtl.imageRoots);
      for (const file of parsed.images) {
        try { await relayCtl.outbox?.enqueueImage(meta.chatId, file); }
        catch (error) { console.warn('[whale-bridge] 图片入队失败：' + String(error?.message ?? error)); }
      }
      // Zero-width space keeps the OpenAI response non-empty when the turn was
      // nothing but a picture, so Whale does not fall back to her own model.
      const visible = parsed.text || '\u200b';
      if (body.stream === true) {
        res.writeHead(200, { 'content-type': 'text/event-stream; charset=utf-8', 'cache-control': 'no-store', connection: 'keep-alive' });
        res.write('data: ' + JSON.stringify({
          id: 'relay-' + Date.now(), object: 'chat.completion.chunk', model: body.model || 'dsh',
          choices: [{ index: 0, delta: { content: visible }, finish_reason: null }],
        }) + '\n\n');
        res.write('data: [DONE]\n\n');
        return res.end();
      }
      return send(res, 200, {
        id: 'relay-' + Date.now(), object: 'chat.completion', created: Math.floor(Date.now() / 1000), model: body.model || 'dsh',
        choices: [{ index: 0, message: { role: 'assistant', content: visible }, finish_reason: 'stop' }],
        usage: { prompt_tokens: 0, completion_tokens: 0, total_tokens: 0 },
      });
    } catch (error) {
      return send(res, error?.status ?? 500, { error: { message: String(error?.message ?? error), type: error?.code ?? 'relay_error' } });
    }
  }

  if (!relayEnabled) {
    // Honour the saved switch on startup, but never block plugin load on it.
    // The env matters: start() without it spawns a child with no
    // WHALE_BRIDGE_LLM_KEY, and every turn then dies with
    // `no credential for provider route "whale-bridge"`.
    state.load().then(async (cfg) => {
      if (cfg.enabled && cfg.autoStart) await supervisor.start({ env: await supervisorEnv() }).catch(() => {});
    }).catch(() => {});

    ctx.effect?.(() => () => { supervisor.stop().catch(() => {}); });
  }

  // Tearing the plugin down must also stop the outbox timer and drop the relay.
  ctx.effect?.(() => () => relayCtl.stop());
}

export { createHostAdapter };
