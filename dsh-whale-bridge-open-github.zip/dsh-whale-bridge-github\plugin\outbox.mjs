/**
 * Outbound queue: assistant text produced in a WeChat-mapped Session by anyone
 * OTHER than a relay turn is queued here, and the Whale-side poller plugin sends
 * it to WeChat on its next tick.
 *
 * WHY A QUEUE: WeChat's send path lives in Whale-Girl, and its JS plugin SDK can
 * call `whale.sendText(chatId, text)` at any time. DSH cannot open a socket into
 * Whale, so the direction is inverted: DSH exposes this queue over the plugin
 * route, and the Whale plugin polls it.
 *
 * WHAT COUNTS AS PROACTIVE: any `assistant/message` committed to a mapped Session
 * outside a relay turn. That covers the speak-up plugin, a scheduled prompt, or
 * the user typing in that session in the sidebar. Relay replies are excluded by
 * marking the turn's final cursor when the turn ends.
 *
 * SAFETY: text and images are only queued for a chat id that already exists in
 * the relay mapping; an image must live INSIDE the configured workspace, be a
 * real file with an accepted extension, and stay under the size cap. Sending
 * failures stay on the queue for the next tick.
 */
import { readFile, writeFile, rename, mkdir } from 'node:fs/promises';
import { existsSync, statSync, readdirSync } from 'node:fs';
import { dirname, isAbsolute, normalize, sep, extname, join } from 'node:path';
import { randomUUID } from 'node:crypto';
import { createRequire } from 'node:module';
import { assistantTextFromEvent } from './relay.mjs';

const requireCjs = createRequire(import.meta.url);
const ASSISTANT = 'assistant/message';
const DEDUPE_MS = 60000;
// Native meme marker: the DSH meme plugin's client renders this into a picture,
// and the bridge resolves the caption to a file so WeChat gets the image too.
const MEME_MARKER = /\[表情\s*[:：]\s*([^\]\r\n]+?)\s*\]/g;
const IMAGE_MARKER = /\[\[image:\s*([^\]\r\n]+?)\s*\]\]/gi;
const MD_IMAGE = /!\[[^\]]*\]\(\s*<?([^)\r\n]+?)>?\s*\)/g;
const FILE_URL = /file:\/\/\/([^\s"'`<>)]+?\.(?:png|jpe?g|webp|gif))/gi;
// A bare absolute image path, as the meme tool and several DSH plugins emit it
// (they put the file's path in the message and let the UI render it). Only the
// path itself is matched; surrounding punctuation stays.
const BARE_PATH = /(?<![\w\\/.:-])((?:[A-Za-z]:[\\/]|\\\\)[^\r\n"'`<>|]*?\.(?:png|jpe?g|webp|gif))(?=$|[\s)"'`,;，。、])/gi;
const IMAGE_EXT = new Set(['.png', '.jpg', '.jpeg', '.webp', '.gif']);
const MAX_IMAGE_BYTES = 10 * 1024 * 1024;

/** Normalised, lowercase roots this queue is allowed to read images from. */
function allowedRoots(workspace, imageRoots) {
  return [workspace, ...(Array.isArray(imageRoots) ? imageRoots : [])]
    .filter((root) => typeof root === 'string' && root)
    .map((root) => normalize(root).toLowerCase().replace(/[\\/]+$/, ''));
}

/** Resolve one candidate path to a real file inside a trusted root, or null. */
function resolveAllowed(raw, roots) {
  let file = String(raw ?? '').trim().replace(/^["'`<]|["'`>]$/g, '');
  if (!file) return null;
  // file:///C:/a.png → C:\a.png (the URL form keeps forward slashes).
  if (/^file:\/\//i.test(file)) { try { file = decodeURIComponent(file.replace(/^file:\/+/i, '')); } catch { return null; } }
  if (/^\/[A-Za-z]:\//.test(file)) file = file.slice(1).replace(/\//g, '\\');
  if (!isAbsolute(file)) return null;
  const full = normalize(file);
  const lower = full.toLowerCase();
  if (!roots.some((root) => lower === root || lower.startsWith(root + sep))) return null;
  if (!IMAGE_EXT.has(extname(full).toLowerCase())) return null;
  let info;
  try { info = statSync(full); } catch { return null; }
  if (!info.isFile() || info.size <= 0 || info.size > MAX_IMAGE_BYTES) return null;
  return full;
}

/**
 * Resolve the meme plugin's `[表情: <caption>]` marker to a real file.
 *
 * The meme pack ships a small SQLite index (`<pack>/index.db`, table `memes`)
 * carrying caption/keywords/tag. Reading it is what lets the bridge turn the same
 * marker the DSH UI renders into a picture into an actual image for WeChat.
 * Cached briefly so a newly added pack is picked up without a restart.
 */
let memeCache = { at: 0, rows: [] };

function loadMemeRows(roots) {
  if (Date.now() - memeCache.at < 60000) return memeCache.rows;
  const rows = [];
  let DatabaseSync = null;
  try { ({ DatabaseSync } = requireCjs('node:sqlite')); } catch { memeCache = { at: Date.now(), rows }; return rows; }
  for (const root of roots) {
    let packs = [];
    try { packs = readdirSync(root, { withFileTypes: true }).filter((entry) => entry.isDirectory()); } catch { continue; }
    for (const pack of packs) {
      const dbPath = join(root, pack.name, 'index.db');
      if (!existsSync(dbPath)) continue;
      try {
        const db = new DatabaseSync(dbPath, { readOnly: true });
        for (const row of db.prepare('SELECT path, caption, keywords, tag FROM memes').all()) {
          if (!row || typeof row.path !== 'string') continue;
          const file = isAbsolute(row.path) ? normalize(row.path) : normalize(join(root, pack.name, row.path));
          rows.push({ file, caption: String(row.caption || ''), keywords: String(row.keywords || ''), tag: String(row.tag || '') });
        }
        db.close();
      } catch { /* unreadable pack: skip, never fail the turn */ }
    }
  }
  memeCache = { at: Date.now(), rows };
  return rows;
}

const normText = (value) => String(value || '').toLowerCase().replace(/\s+/g, '');

/** Best matching meme file for a description, or null. */
export function resolveMemeFile(description, roots) {
  const q = normText(description);
  if (!q) return null;
  let best = null;
  let bestScore = 0;
  for (const row of loadMemeRows(roots)) {
    const caption = normText(row.caption);
    let score = 0;
    if (caption && caption === q) score = 100;
    else if (caption && caption.includes(q)) score = 80;
    else if (caption && q.includes(caption)) score = 70;
    else if (row.keywords && normText(row.keywords).includes(q)) score = 60;
    else if (row.tag && q.includes(normText(row.tag))) score = 50;
    if (score > bestScore) { bestScore = score; best = row; }
  }
  return bestScore >= 50 ? best.file : null;
}

/**
 * Pull image references out of an assistant message, in all the shapes this
 * deployment produces:
 *
 *   1. `[[image: <path>]]`      explicit marker (documented contract)
 *   2. `![alt](<path>)`         markdown image; some tools quote paths this way
 *   3. `file:///<path>`         URL form
 *   4. a bare `<X>:\...\a.png`  what the meme tool actually emits
 *
 * Each accepted reference becomes one image item, and the reference text is
 * removed so WeChat never shows a raw path. A reference outside the trusted
 * roots is left untouched (it is just text at that point); nothing is ever read
 * from outside those roots.
 */
export function extractImageReferences(text, workspace, imageRoots = []) {
  const out = { text: String(text ?? ''), images: [] };
  const rawRoots = [workspace, ...(Array.isArray(imageRoots) ? imageRoots : [])]
    .filter((root) => typeof root === 'string' && root);
  const roots = allowedRoots(workspace, imageRoots);
  if (!out.text || roots.length === 0) return out;
  const take = (match, raw, stripMatch = true) => {
    const full = resolveAllowed(raw, roots);
    if (!full) return match;
    if (!out.images.includes(full)) out.images.push(full);
    return stripMatch ? '' : match;
  };
  let value = out.text;
  // Native meme marker first: the client renders it as a picture, and resolving
  // the caption here is what lets WeChat receive the same image.
  value = value.replace(MEME_MARKER, (marker, description) => {
    const resolved = resolveMemeFile(description, rawRoots);
    const full = resolved ? resolveAllowed(resolved, roots) : null;
    if (!full) return marker; // unknown caption: keep the text rather than eat it
    if (!out.images.includes(full)) out.images.push(full);
    return '';
  });
  // The marker syntax belongs to this bridge: strip it even when the path is not
  // acceptable, so a WeChat recipient never sees `[[image: ...]]` in prose.
  value = value.replace(IMAGE_MARKER, (_m, raw) => {
    const full = resolveAllowed(raw, roots);
    if (full && !out.images.includes(full)) out.images.push(full);
    return '';
  });
  value = value.replace(MD_IMAGE, (m, raw) => take(m, raw));
  value = value.replace(FILE_URL, (m, raw) => take(m, raw));
  value = value.replace(BARE_PATH, (m, raw) => take(m, raw));
  out.text = value.replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim();
  return out;
}

/** Marker-only parser, kept for callers and tests that predate bare paths. */
export function splitImageMarkers(text, workspace, imageRoots = []) {
  const out = { text: String(text ?? ''), images: [] };
  const roots = allowedRoots(workspace, imageRoots);
  if (!out.text || roots.length === 0) return out;
  out.text = out.text.replace(IMAGE_MARKER, (match, raw) => {
    const full = resolveAllowed(raw, roots);
    if (full && !out.images.includes(full)) out.images.push(full);
    return '';
  }).replace(/\n{3,}/g, '\n\n').trim();
  return out;
}

export function createOutbox({
  getController,
  getMappings,
  isBusy = () => false,
  workspace = '',
  imageRoots = [],
  stateFile,
  intervalMs = 10000,
  logger = () => {},
}) {
  let pending = [];
  let seen = {};
  let loaded = false;
  let timer = null;
  let scanning = false;
  let writing = Promise.resolve();

  const persist = () => {
    const snapshot = JSON.stringify({ pending, seen }, null, 2) + '\n';
    writing = writing.then(async () => {
      await mkdir(dirname(stateFile), { recursive: true });
      const temp = stateFile + '.tmp-' + randomUUID();
      await writeFile(temp, snapshot, { encoding: 'utf8', mode: 0o600 });
      await rename(temp, stateFile);
    }).catch((error) => logger('[outbox] persist failed: ' + String(error?.message ?? error)));
    return writing;
  };

  async function load() {
    if (loaded) return;
    try {
      const raw = JSON.parse(await readFile(stateFile, 'utf8'));
      pending = Array.isArray(raw?.pending) ? raw.pending : [];
      seen = raw && typeof raw.seen === 'object' && raw.seen ? raw.seen : {};
    } catch { pending = []; seen = {}; }
    loaded = true;
  }

  /**
   * First run of a session: remember its current cursor so history that predates
   * the queue is never replayed to WeChat.
   */
  async function prime() {
    const api = getController?.();
    if (!api) return;
    const mappings = await Promise.resolve(getMappings?.() ?? []);
    for (const { sessionId } of mappings) {
      if (typeof seen[sessionId] === 'number') continue;
      try {
        const state = await api.state({ sessionId }, new AbortController().signal);
        seen[sessionId] = Number(state?.cursor) || 0;
      } catch { /* unreadable session: leave it unprimed, scan will skip */ }
    }
    await persist();
  }

  async function enqueue(chatId, text) {
    const clean = String(text ?? '').trim();
    if (!chatId || !clean) return null;
    const duplicate = pending.some((item) => item.chatId === chatId && item.kind !== 'image' && item.text === clean && Date.now() - item.at < DEDUPE_MS);
    if (duplicate) return null;
    const item = { id: randomUUID(), chatId, kind: 'text', text: clean, at: Date.now() };
    pending.push(item);
    await persist();
    logger('[outbox] queued text for ' + chatId.slice(0, 8) + ': ' + clean.slice(0, 40));
    return item;
  }

  /** Queue one already-validated image file. Text dedupe does not apply. */
  async function enqueueImage(chatId, file) {
    if (!chatId || !file) return null;
    const duplicate = pending.some((item) => item.chatId === chatId && item.kind === 'image' && item.file === file && Date.now() - item.at < DEDUPE_MS);
    if (duplicate) return null;
    const item = { id: randomUUID(), chatId, kind: 'image', file, at: Date.now() };
    pending.push(item);
    await persist();
    logger('[outbox] queued image for ' + chatId.slice(0, 8) + ': ' + file);
    return item;
  }

  function list(limit = 20) {
    return pending.slice(0, Math.max(1, Math.min(Number(limit) || 20, 100)));
  }

  async function ack(ids) {
    const set = new Set((Array.isArray(ids) ? ids : []).map(String));
    if (set.size === 0) return 0;
    const before = pending.length;
    pending = pending.filter((item) => !set.has(item.id));
    await persist();
    return before - pending.length;
  }

  /** A relay turn finished at `cursor`: its reply must never be sent back out. */
  async function markTurn(sessionId, cursor) {
    if (typeof cursor !== 'number' || !Number.isFinite(cursor)) return;
    seen[sessionId] = Math.max(seen[sessionId] ?? 0, cursor);
    await persist();
  }

  async function scan() {
    if (scanning) return;
    scanning = true;
    try {
      const api = getController?.();
      if (!api || typeof api.state !== 'function' || typeof api.wait !== 'function') return;
      await load();
      const mappings = await Promise.resolve(getMappings?.() ?? []);
      for (const { chatId, sessionId } of mappings) {
        if (isBusy(sessionId)) continue;
        const ac = new AbortController();
        let state;
        try { state = await api.state({ sessionId }, ac.signal); } catch { continue; }
        const cursor = Number(state?.cursor) || 0;
        const from = typeof seen[sessionId] === 'number' ? seen[sessionId] : cursor;
        if (typeof seen[sessionId] !== 'number') { seen[sessionId] = from; continue; }
        if (cursor <= from) continue;
        let result;
        try { result = await api.wait({ sessionId, afterSeq: from, timeoutMs: 1 }, ac.signal); } catch { continue; }
        for (const record of result?.output?.records ?? []) {
          const event = record?.event ?? record;
          if (event?.type !== ASSISTANT) continue;
          const raw = assistantTextFromEvent(event);
          if (!raw) continue;
          const parsed = extractImageReferences(raw, workspace, imageRoots);
          if (parsed.text) await enqueue(chatId, parsed.text);
          for (const file of parsed.images) await enqueueImage(chatId, file);
        }
        seen[sessionId] = Math.max(from, Number(result?.state?.cursor) || cursor);
        await persist();
      }
    } finally {
      scanning = false;
    }
  }

  return {
    load,
    list,
    enqueue,
    enqueueImage,
    ack,
    markTurn,
    scan,
    async start() {
      await load();
      await prime();
      timer = setInterval(() => { scan().catch((error) => logger('[outbox] scan failed: ' + String(error?.message ?? error))); }, intervalMs);
      if (typeof timer.unref === 'function') timer.unref();
      logger('[outbox] started, interval=' + intervalMs + 'ms, pending=' + pending.length);
      return pending.length;
    },
    stop() { if (timer) { clearInterval(timer); timer = null; } },
  };
}
